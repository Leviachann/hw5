#include <iostream>
using namespace std;
class Computer {
  char *model = nullptr;
  char *vendor = nullptr;
  char *videocard = nullptr;
  char *monitor = nullptr;
  int objectId;
  int cpu_hz;
  int core;
  int disk_size;
  int ram;
  bool isSSD = false;

public:
  static int staticId;
  Computer() {
    model = new char[100]{"Msi Titan GT77"};
    monitor = new char[100]{"LED?"};
    videocard = new char[100]{"NVIDIA TITAN V"};
    core = 9;
    cpu_hz = 12900;
    disk_size = 666;
    isSSD = true;
    ram = 12;
  }
  Computer(const char *m, const char *v, const char *mn, int oid, int c, int cph,
           const char *vc, int ds, bool iss) {
    SetModel(m);
    SetMonitor(mn);
    SetId(oid);
    SetCPUHZ(cph);
    SetCore(c);
    SetVideoCard(vc);
    SetDiskSize(ds);
    IsSSD(iss);
    SetVendor(v);
  }
  void ShowDebtor() {
    cout << "Model: " << model << "\nMonitor: " << monitor
         << "\nId: " << objectId << "\nCore: " << core << "\nCPU HZ: " << cpu_hz
         << "\nVideo Card: " << videocard << "\nDisk Size: " << disk_size
         << "Vendor: " << vendor << endl;
  }
  void SetModel(const char *n) {
    delete[] model;
    model = new char[strlen(n) + 1];
    strcpy_s(model, strlen(n) + 1, n);
  }
  void SetVendor(const char *sn) {
    delete[] vendor;
    model = new char[strlen(sn) + 1];
    strcpy_s(vendor, strlen(sn) + 1, sn);
  }
  void SetMonitor(const char *wa) {
    delete[] monitor;
    monitor = new char[strlen(wa) + 1];
    strcpy_s(monitor, strlen(wa) + 1, wa);
  }
  void SetVideoCard(const char *la) {
    delete[] videocard;
    videocard = new char[strlen(la) + 1];
    strcpy_s(videocard, strlen(la) + 1, la);
  }
  void SetId(int idd) { objectId = staticId++; }
  int SetDiskSize(int db) { disk_size = db; }
  void SetCore(int c) { core = c; }
  bool SetHasLatePayment(bool hpl) { isSSD = IsSSD(disk_size); }
  bool IsSSD(bool hlp) {
    if (disk_size > 900000)
      return true;
  }
  int SetCPUHZ(int cph) { cpu_hz = 0 < cph && cph < 100 ? cph : 5; }
  int GetId() { return objectId; }
  int GetDebt() { return disk_size; }
  int GetSalary() { return core; }
  int GetPhoneNumber() { return cpu_hz; }
  bool GetHasLatePayment() { return isSSD; }
  const char *GetName() { return model; }
  const char *GetSurname() { return vendor; }
  const char *GetWorkAddress() { return monitor; }
  const char *GetLiveAddress() { return videocard; }
  ~Computer() {
    delete[] model;
    delete[] monitor;
    delete[] videocard;
    delete[] vendor;
  }
};
class ComputerStore {
  char *store_name;
  Computer **debtors;
  int debtorsCount = Computer::staticId + 1;
  ComputerStore(Computer *debts, int size) {
    debtorsCount = size;
    debtors = (Computer)[debtorsCount];
    for (int i = 0; i < debtorsCount; i++) {
      debtors[i]->SetModel(debts[i].GetName());
      debtors[i]->SetId(debts[i].GetId());
      debtors[i]->SetCPUHZ(debts[i].GetPhoneNumber());
      debtors[i]->SetMonitor(debts[i].GetWorkAddress());
      debtors[i]->SetCore(debts[i].GetSalary());
    }
  }
  void ShowAllDebtors(int size) {
    debtorsCount = size;
    for (size_t i = 0; i < debtorsCount; i++) {
      debtors[i]->ShowDebtor();
    }
  }
  Computer &GetLateDebtor() {
    for (int i = 0; i < debtorsCount; i++) {
      if (debtors[i]->SetHasLatePayment(debtors[i]->GetHasLatePayment()) ==
          true) {
        debtors[i]->ShowDebtor();
      }
    }
  }
  Computer &GetTooMuchDebtor(int disk_size) {
    for (int i = 0; i < debtorsCount; i++) {
      if (debtors[i]->SetDiskSize(debtors[i]->GetDebt()) > 1000.00) {
        debtors[i]->ShowDebtor();
      }
    }
  }
};
void AddDebtor(Computer *&debts, int size, Computer &d) {
  Computer *temp = new Computer[size + 1];
  for (int i = 0; i < size; i++) {
    temp[i].SetId(debts[i].GetId());
    temp[i].SetModel(debts[i].GetName());
    temp[i].SetVendor(debts[i].GetSurname());
    temp[i].SetMonitor(debts[i].GetWorkAddress());
    temp[i].SetVideoCard(debts[i].GetLiveAddress());
    temp[i].SetCore(debts[i].GetSalary());
    temp[i].SetDiskSize(debts[i].GetDebt());
    temp[i].SetHasLatePayment(debts[i].GetHasLatePayment());
    temp[i].SetCPUHZ(debts[i].GetPhoneNumber());
  }
}
static int staticId = 1;
int main() {}