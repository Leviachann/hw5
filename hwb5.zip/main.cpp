#include <iostream>
using namespace std;
class Computer {
  char *model = nullptr;
  char *vendor = nullptr;
  char *videocard = nullptr;
  char *monitor = nullptr;
  int objectId;
  int cpu_hz;
  int core;
  int disk_size;
  int ram;
  bool isSSD = false;
public:
  static int staticId;
  Computer() {
    model = new char[100]{"Msi Titan GT77"};
    monitor = new char[100]{"LED?"};
    vendor=new char[100]{"???"};
    videocard = new char[100]{"NVIDIA TITAN V"};
    core = 9;
    cpu_hz = 12900;
    disk_size = 666;
    isSSD = true;
    ram = 12;
  }
  Computer(const char *m, const char *v, const char *mn, int oid, int c, int cph,
           const char *vc, int ds, bool iss,int r) {
    SetModel(m);
    SetMonitor(mn);
    SetId(oid);
    SetCPUHZ(cph);
    SetCore(c);
    SetVideoCard(vc);
    SetDiskSize(ds);
    IsSSD(iss);
    SetVendor(v);
    SetRAM(r);
  }
  void ShowComputer() {
    cout << "Model: " << model << "\nMonitor: " << monitor
         << "\nId: " << objectId << "\nCore: " << core << "\nCPU HZ: " << cpu_hz
         << "\nVideo Card: " << videocard << "\nDisk Size: " << disk_size
         << "\nVendor: " << vendor <<"\nRAM"<<ram<< endl;
  }
  void SetModel(const char *m) {
    delete[] model;
    model = new char[strlen(m) + 1];
    strcpy_s(model, strlen(m) + 1, n);
  }
  void SetVendor(const char *v) {
    delete[] vendor;
    model = new char[strlen(v) + 1];
    strcpy_s(vendor, strlen(v) + 1, v);
  }
  void SetMonitor(const char *mn) {
    delete[] monitor;
    monitor = new char[strlen(mn) + 1];
    strcpy_s(monitor, strlen(mn) + 1, mn);
  }
  void SetVideoCard(const char *vc) {
    delete[] videocard;
    videocard = new char[strlen(vc) + 1];
    strcpy_s(videocard, strlen(vc) + 1, vc);
  }
  void SetId(int idd) { objectId = staticId++; }
  int SetDiskSize(int ds) { disk_size = ds; }
  int SetRAM(int r) { ram = r; }
  void SetCore(int c) { core = c; }
  bool SetIsSSD(bool cph) { isSSD = IsSSD(disk_size); }
  bool IsSSD(bool iss) {
    if (disk_size > 900000)
      return true;
  }
  int SetCPUHZ(int cph) { cpu_hz = 0 < cph && cph < 100 ? cph : 5; }
  int GetId() { return objectId; }
  int GetDiskSize() { return disk_size; }
  int GetCore() { return core; }
  int GetRAM(){return ram;}
  int GetCPUHZ() { return cpu_hz; }
  bool GetIsSSD() { return isSSD; }
  const char *GetModel() { return model; }
  const char *GetVendor() { return vendor; }
  const char *GetMonitor() { return monitor; }
  const char *GetVideoCard() { return videocard; }

	bool ShowComputer GetRAM( Int& r) { cout<<ram; }
  bool ShowComputer GetCore( Int& c) { cout<<core; }
  bool ShowComputer GetDiskSize( Int& ds) { cout<<disk_size; }
  bool ShowComputer GetID( Int& idd) { cout<<object_Id; }
  bool ShowComputer GetCPUHZ( Int& cp) { cout<<cpu_hz; }
  bool ShowComputer GetIsSSD( bool& iss) { cout<<isSSD; }
  bool ShowComputer GetModel( char& m) { cout<<model; }
  bool ShowComputer GetVendor( char& v) { cout<<vendor; }
  bool ShowComputer GetMonitor( char& mn) { cout<<monitor; }
  bool ShowComputer GetVideoCard( char& vc) { cout<<videocard; }

	bool ShowComputer SetRAM( Int& r) { cin<<ram; }
  bool ShowComputer SetCore( Int& c) { cin<<core; }
  bool ShowComputer SetDiskSize( Int& ds) { cin<<disk_size; }
  bool ShowComputer SetID( Int& idd) { cin<<object_Id; }
  bool ShowComputer SetCPUHZ( Int& cp) { cin<<cpu_hz; }
  bool ShowComputer SetIsSSD( bool& iss) { cin<<isSSD; }
  bool ShowComputer SetModel( char& m) { cin<<model; }
  bool ShowComputer SetVendor( char& v) { cin<<vendor; }
  bool ShowComputer SetMonitor( char& mn) { cin<<monitor; }
  bool ShowComputer SetVideoCard( char& vc) { cin<<videocard; }
  ~Computer() {
    delete[] model;
    delete[] monitor;
    delete[] videocard;
    delete[] vendor;
  }
};
class ComputerStore {
  char *store_name;
  Computer **computers;
  int computersCount = Computer::staticId + 1;
  ComputerStore(Computer *pcs, int size) {
    computersCount = size;
    computers = (Computer)[computersCount];
    for (int i = 0; i < computersCount; i++) {
      computers[i]->SetModel(pcs[i].GetModel());
      computers[i]->SetId(pcs[i].GetId());
      computers[i]->SetCPUHZ(pcs[i].GetIsSDD());
      computers[i]->SetMonitor(pcs[i].GetMonitor());
      computers[i]->SetCore(pcs[i].GetCore());
      computers[i]->SetRAM(pcs[i].GetRAM());
    }
  }
  void ShowAllDebtors(int size) {
    computersCount = size;
    for (size_t i = 0; i < computersCount; i++) {
      computers[i]->ShowComputer();
    }
  }
  Computer &IsSSD() {
    for (int i = 0; i < computersCount; i++) {
      if (computers[i]->SetIsSSD(computers[i]->GetIsSSD()) ==
          true) {
        computers[i]->ShowComputer();
      }
    }
  }
};
void AddDebtor(Computer *&pcs, int size, Computer &d) {
  Computer *temp = new Computer[size + 1];
  for (int i = 0; i < size; i++) {
    temp[i].SetId(pcs[i].GetId());
    temp[i].SetModel(pcs[i].GetModel());
    temp[i].SetVendor(pcs[i].GetVendor());
    temp[i].SetMonitor(pcs[i].GetMonitor());
    temp[i].SetVideoCard(pcs[i].GetVideoCard());
    temp[i].SetCore(pcs[i].GetCore());
    temp[i].SetDiskSize(pcs[i].GetDiskSize());
    temp[i].SetIsSSD(pcs[i].GetIsSSD());
    temp[i].SetCPUHZ(pcs[i].GetIsSDD());
    temp[i]->SetRAM(pcs[i].GetRAM());
  }
}
static int staticId = 1;
int main() {}